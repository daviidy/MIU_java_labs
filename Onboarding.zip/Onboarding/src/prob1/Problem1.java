package prob1;

public class Problem1 {

	/**
	 * This method returns your name
	 */
	public static String myName() {
		return "David YAO";
		//implement
	}
	
	
    //test your code
	//Expected output: your  name
	public static void main(String[] args) {
		String name = myName();
		System.out.println(name);

	}

}
