package prob3;
import java.util.Random;

public class Problem3 {

	/**
	 * This method returns any integer that lies between 3 and 5
	 */
	public static int between3and5() {
		Random r = new Random();
		return r.nextInt((5 - 3) + 1) + 3;
	}
	
	
    //test your code
	//Expected output: 4
	public static void main(String[] args) {
		int between = between3and5();
		System.out.println(between);

	}

}
