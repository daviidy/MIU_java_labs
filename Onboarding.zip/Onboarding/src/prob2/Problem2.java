package prob2;

public class Problem2 {

	/**
	 * This method returns the sum of the integers 1, 2, 3
	 */
	public static int sum() {
		return 1 + 2 + 3;
		//implement
	}
	
	
    //test your code
	//Expected output: 6
	public static void main(String[] args) {
		int sum = sum();
		System.out.println(sum);

	}
}
