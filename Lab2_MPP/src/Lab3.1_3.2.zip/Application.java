import java.util.*;

public class Application {

	public static void main(String[] args) {
		Employee emp1 = new Employee(1, "dave", "zer", "middle", "14-10-1994", 23344, 2500);
		Employee emp2 = new Employee(2, "armel", "hgf", "sgfg", "14-10-1995", 23344, 3500);
		Employee emp3 = new Employee(3, "ted", "fg", "bgb", "14-10-1996", 23344, 4500);
		Employee emp4 = new Employee(4, "ggr", "ergr", "rg", "14-10-1997", 23344, 5500);
				
		Position pos1 = new Position("dev", "any description", emp1, new ArrayList(), null);
		Position pos2 = new Position("front", "any dfrgr", emp2, new ArrayList(), pos1);
		Position pos3 = new Position("devops", "any dfrgr", emp3, new ArrayList(), pos1);
		Position pos4 = new Position("sysadmin", "any dfrgr", emp4, new ArrayList(), pos1);
		
//		pos1.addInferior(pos3);
//		pos1.addInferior(pos4);
				
		Department dep1 = new Department("marketing", "new york", new ArrayList());
		Department dep2 = new Department("tech", "iowa", new ArrayList());
		
		List<Department> departments = new ArrayList();
		
		dep1.addPos(pos1);
		dep2.addPos(pos2);
		
		Company comp = new Company("apple", departments);
		
		comp.addDept(dep1);
		comp.addDept(dep2);
		
		
		comp.print();
		System.out.printf("\tTotal Salary: %.2f", comp.getSalary());
		
//		System.out.printf("me%n");
//		System.out.printf("\tme%n");
//		System.out.printf("\t\tme%n\tyou");
		
	}

}
