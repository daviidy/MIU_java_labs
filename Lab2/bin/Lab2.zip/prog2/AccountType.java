package prog2;
public enum AccountType {
	CHECKING,
	SAVINGS,
	RETIREMENT
}
