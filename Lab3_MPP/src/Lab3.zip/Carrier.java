
abstract class Carrier implements ICarrier {

	public abstract double calcPrice(Package pack);

	public abstract String getName();

}
