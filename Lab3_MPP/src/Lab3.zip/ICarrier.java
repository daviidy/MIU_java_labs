
public interface ICarrier {
		
	double calcPrice(Package pack);
	String getName();

}
