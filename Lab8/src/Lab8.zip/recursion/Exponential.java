package recursion;

public class Exponential {
	double power(double x,int n) {
		if (n == 1) {
			return n;
		}
		return x * power(x, n-1);
	}
	
	public static void main(String[] args) {
		Exponential expo = new Exponential();
		double res = expo.power(2, 10);
		System.out.println(res);
	}
}
