package exceptions.prog_2;

public class OverdrawnAccountException extends Exception {
	
}
