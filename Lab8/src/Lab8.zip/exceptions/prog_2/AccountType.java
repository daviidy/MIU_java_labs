package exceptions.prog_2;

public enum AccountType {
	CHECKING, 
	SAVINGS, 
	RETIREMENT;
}
