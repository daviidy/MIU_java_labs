package exceptions.prog_1;

public class IllegalClosedCurveException {

}
