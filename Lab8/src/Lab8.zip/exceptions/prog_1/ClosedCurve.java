package exceptions.prog_1;

abstract public class ClosedCurve {
	abstract double computeArea();

}
