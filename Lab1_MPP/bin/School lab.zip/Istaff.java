
public interface Istaff {

}
