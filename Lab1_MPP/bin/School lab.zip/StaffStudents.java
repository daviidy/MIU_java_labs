
public class StaffStudents extends Student {
	private Staff staff;

	public StaffStudents(String name, String phone, int age, double GPA, Staff staff) {
		super(name, phone, age, GPA);
		this.staff = staff;
	}
	
	
}
