package prog2;

abstract class ClosedCurve {
	abstract double computeArea();
}
