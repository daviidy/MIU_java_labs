package prog3;
public enum AccountType {
	CHECKING,
	SAVINGS,
	RETIREMENT
}
